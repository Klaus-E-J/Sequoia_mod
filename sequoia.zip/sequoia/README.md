# Sequoia
This mod will add to minetest the sequoia tree, if you want the sequoia from the image just rename the .mts files to "sequoia_tree", make sure to dont delete any file.

## Technic chainsaw

Add this to technic/technic/tools/chainsaw.lua to enable support for maple trees for the chainsaw tool.

```
-- Support sequoia
if minetest.get_modpath("sequoia") then
	timber_nodenames["sequoia:sequoia_tree"]         = true
	if chainsaw_leaves then
		timber_nodenames["sequoia:sequoia_leaves"] = true
	end
end
```

