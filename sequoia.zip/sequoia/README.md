# Sequoia
Maple Tree for Minetest by ExeterDadThis mod will add to the Minetest Game a Giant Sequoia. if you dont want a huge tree you can chance the name from the schematics in the schematics folder, there you will find the files, choose one.


## Technic chainsaw

Add this to technic/technic/tools/chainsaw.lua to enable support for maple trees for the chainsaw tool.

```
-- Support sequoia
if minetest.get_modpath("sequoia") then
	timber_nodenames["sequoia:sequoia_tree"]         = true
	if chainsaw_leaves then
		timber_nodenames["sequoia:sequoia_leaves"] = true
	end
end
```

