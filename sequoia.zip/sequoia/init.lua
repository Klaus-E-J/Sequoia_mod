minetest.log("Loading sequoia")
sequoia = {}
dofile(minetest.get_modpath("sequoia").."/trees.lua")

minetest.register_node("sequoia:sequoia_tree", {
	description = "Sequoia Tree",
	tiles = {"sequoia_tree_top.png", "sequoia_tree_top.png", "sequoia_tree.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {tree = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node("sequoia:sequoia_wood", {
	description = "Sequoia Wood Planks",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"sequoia_wood.png"},
	is_ground_content = false,
	groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2, wood = 1},
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("sequoia:sequoia_leaves", {
	description = "Sequoia Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"sequoia_leaves.png"},
	special_tiles = {"sequoia_leaves_simple.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'sequoia:sequoia_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'sequoia:sequoia_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})



minetest.register_node("sequoia:sequoia_sapling", {
	description = "Sequoia Sapling",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"sequoia_sapling.png"},
	inventory_image = "sequoia_sapling.png",
	wield_image = "sequoia_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = sequoia.grow_sapling,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(2400,4800))
	end,

	on_place = function(itemstack, placer, pointed_thing)
	print("Sequoia sapling placed.")
		itemstack = default.sapling_on_place(itemstack, placer, pointed_thing,
			"sequoia:sequoia_sapling",
			-- minp, maxp to be checked, relative to sapling pos
			-- minp_relative.y = 1 because sapling pos has been checked
			{x = -2, y = 1, z = -2},
			{x = 2, y = 13, z = 2},
			-- maximum interval of interior volume check
			4)

		return itemstack
	end,
})


minetest.register_decoration({
	deco_type = "schematic",
	place_on = {"default:dirt_with_grass"},
	sidelen = 16,
	noise_params = {
		offset = 0.0,
		--scale = -0.015,
		scale = 0.007,
		spread = {x = 250, y = 250, z = 250},
		seed = 410,
		octaves = 3,
		persist = 1.00
	},
	biomes = {"deciduous_forest"},
	y_min = 1,
	y_max = 31000,
	schematic = minetest.get_modpath("sequoia").."/schematics/sequoia_tree.mts",
	flags = "place_center_x, place_center_z",
})


default.register_leafdecay({
	trunks = {"sequoia:sequoia_tree"},
	leaves = {"sequoia:sequoia_leaves"},
	radius = 3,
})
	
default.register_fence("sequoia:fence_sequoia_wood", {
	description = "Sequoia Fence",
	texture = "sequoia_wood.png",
	material = "sequoia:sequoia_wood",
	groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2},
	sounds = default.node_sound_wood_defaults()
})

minetest.register_craft({
	output = 'sequoia:sequoia_wood 4',
	recipe = {
		{'sequoia:sequoia_tree'},
	}
})

minetest.register_craft({
	type = "fuel",
	recipe = "sequoia:sequoia_sapling",
	burntime = 12,
})

minetest.register_craft({
	type = "fuel",
	recipe = "sequoia:fence_sequoia_wood",
	burntime = 8,
})


-- integration with bonemeal
if minetest.get_modpath("bonemeal") then
	bonemeal:add_sapling({
		{"sequoia:sequoia_sapling", sequoia.grow_sapling, "soil"},
	})                                                
end

-- derivative blocks (stairs / microblocks / etc)
if stairs and stairs.mod and stairs.mod == "redo" then

	stairs.register_all("sequoia_wood", "sequoia:sequoia_wood",
		{choppy = 2, oddly_breakable_by_hand = 1, flammable = 3},
		{"sequoia_wood.png"},
		"Sequoia Wood Stair",
		"Sequoia Wood Slab",
		default.node_sound_wood_defaults())
                                                     
	stairs.register_all("sequoia_tree", "sequoia:sequoia_tree",
		{choppy = 2, oddly_breakable_by_hand = 1, flammable = 3},
		{"sequoia_tree_top.png", "sequoia_tree_top.png", "sequoia_tree.png"},
		"Sequoia Trunk Stair",
		"Sequoia Trunk Slab",
		default.node_sound_wood_defaults())
                                                                                        
elseif minetest.global_exists("stairsplus") then
                                                                                        
	stairsplus:register_all("sequoia", "sequoia_wood", "sequoia:sequoia_wood", {
		description = "Sequoia Wood",
		tiles = {"sequoia_wood.png"},
		groups = {choppy = 2, oddly_breakable_by_hand = 1, flammable = 3},
		sounds = default.node_sound_wood_defaults(),
	})
                                                                                        
	stairsplus:register_all("sequoia", "sequoia_tree", "sequoia:sequoia_tree", {
		description = "Sequoia Trunk",
		tiles = {"sequoia_tree_top.png", "sequoia_tree_top.png", "sequoia_tree.png"},
		groups = {choppy = 2, oddly_breakable_by_hand = 1, flammable = 3},
		sounds = default.node_sound_wood_defaults(),
	})
                                                                                        
else

	stairs.register_stair_and_slab("sequoia_wood", "sequoia:sequoia_wood",
		{choppy = 2, oddly_breakable_by_hand = 1, flammable = 3},
		{"sequoia_wood.png"},
		"Sequoia Stair",
		"Sequoia Slab",
		default.node_sound_wood_defaults())
                                                                                        
	stairs.register_stair_and_slab("sequoia_tree", "sequoia:sequoia_tree",
		{choppy = 2, oddly_breakable_by_hand = 1, flammable = 3},
		{"sequoia_tree_top.png", "sequoia_tree_top.png", "sequoia_tree.png"},
		"Sequoia Trunk Stair",
		"Sequoia Trunk Slab",
		default.node_sound_wood_defaults())

                               
end
                                                                                        

              
-- procedurally-generated arcs
if minetest.get_modpath("pkarcs") then
	pkarcs.register_node("sequoia:sequoia_wood")
end
