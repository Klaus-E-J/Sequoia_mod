local random = math.random

-- 
local function is_snow_nearby(pos)
	return minetest.find_node_near(pos, 1,
		{"default:snow", "default:snowblock", "default:dirt_with_snow"})
end


-- Sapling ABM

function sequoia.grow_sapling(pos)
	if not default.can_grow(pos) then
		-- Can't grow yet, try later.
		minetest.get_node_timer(pos):start(math.random(240, 600))
		return
	end

	local mg_name = minetest.get_mapgen_setting("mg_name")
	local node = minetest.get_node(pos)

	if node.name == "sequoia:sequoia_sapling" then
		minetest.log("action", "An sequoia sapling grows into a tree at "..
			minetest.pos_to_string(pos))
		minetest.remove_node(pos)
		sequoia.grow_new_sequoia_tree(pos)
	end
end

minetest.register_lbm({
	name = "sequoia:convert_saplings_to_node_timer",
	nodenames = {"sequoia:sequoia_sapling"},
	action = function(pos)
		minetest.get_node_timer(pos):start(math.random(1200, 2400))
	end
})

--
--
--

-- New sequoia tree

function sequoia.grow_new_sequoia_tree(pos)
	local path = minetest.get_modpath("sequoia") ..
		"/schematics/sequoia_tree.mts"
	minetest.place_schematic({x = pos.x - 7, y = pos.y, z = pos.z - 7},
		path, "0", nil, false)
end



